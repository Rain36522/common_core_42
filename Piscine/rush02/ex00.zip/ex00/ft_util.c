/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_util.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pudry <marvin@42lausanne.ch>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/24 12:46:33 by pudry             #+#    #+#             */
/*   Updated: 2023/06/24 17:06:07 by pudry            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

/*this function return the quantity value of character without the end null*/
int	ft_strlen(char	*str)
{
	int	i;

	i = 0;
	while (str[i])
		i ++;
	return (i);
}

/*This function print the array of string. Without the last space if they
 * are present*/
void	ft_put_array(char **str)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			if (!(!(str[i + 1]) && !(str[i][j + 1]) && str[i][j] == ' '))
				write(1, &str[i][j], 1);
			j ++;
		}
		i ++;
	}
	write(1, "\n", 1);
}

/*this function compare two strings*/
int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] == s2[i] && s1[i])
		i ++;
	return (s1[i] - s2[i]);
}

/*This function calcul the  size of my array with the null value */
int	ft_array_len(char *str)
{
	int	iasize;
	int	istr_size;

	iasize = 1;
	istr_size = ft_strlen(str);
	if (istr_size == 1)
		return (iasize + 1);
	if (str[istr_size - 1] == '1')
		istr_size --;
	return (istr_size + 1);
}	
