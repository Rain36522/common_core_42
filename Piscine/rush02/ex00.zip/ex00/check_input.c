/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_input.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pudry <marvin@42lausanne.ch>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/24 13:10:01 by pudry             #+#    #+#             */
/*   Updated: 2023/06/24 15:41:28 by pudry            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*This function make a verification of the user input and if there is an 
 * error, they return error.*/
int	ft_check_input_nbr(char *cnbr)
{
	if (!(*cnbr))
		return (0);
	while (*cnbr >= 48 && *cnbr <= 57 && *cnbr)
		cnbr ++;
	if (*cnbr)
		return (0);
	return (1);
}
